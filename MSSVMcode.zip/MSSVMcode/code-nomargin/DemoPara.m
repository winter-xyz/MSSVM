clear
clc

SVMFunName = 'MSSVM';
SVMFun = str2func(SVMFunName);%�ַ���ת���ɺ�����
FunPara.kerfPara.type = 'lin';  %�˲���linΪ���Ժ�,rbfΪ��˹��
DirPath = sprintf('./Result/%s/Linearly/',SVMFunName);
if ~exist(DirPath,'dir')
    mkdir(DirPath);%�����ļ���
end
for RunTimes = 1:10
    FilePath = sprintf('%s%s%d.txt',DirPath,SVMFunName,RunTimes);
    fid = fopen(FilePath, 'wt');
    fprintf(fid, '%s Experment Time is %s \n', SVMFunName,date);
    DataNum = 28;
    DataPath(1) = {'./Data/UCI/Aggregation.mat'};
    DataPath(2) = {'./Data/UCI/Compound.mat'};
    DataPath(3) = {'./Data/UCI/Dermatology.mat'};
    DataPath(4) = {'./Data/UCI/Dcoli.mat'};
    DataPath(5) = {'./Data/UCI/Far.mat'};
    DataPath(6) = {'./Data/UCI/Iris.mat'};
    DataPath(7) = {'./Data/UCI/Libras.mat'};
    DataPath(8) = {'./Data/UCI/Pathbased.mat'};
    DataPath(9) = {'./Data/UCI/Seeds.mat'};
    DataPath(10) = {'./Data/UCI/Vehicle.mat'};
    DataPath(11) = {'./Data/UCI/Wine.mat'};
    DataPath(12) = {'./Data/UCI/Zoo.mat'};
    DataPath(13) = {'./Data/UCI/Australian.mat'};
    DataPath(14) = {'./Data/UCI/Echocardiogram.mat'};
    DataPath(15) = {'./Data/UCI/Hourse.mat'};
    DataPath(16) = {'./Data/UCI/Heartstatlog.mat'};
    DataPath(17) = {'./Data/UCI/Heartc.mat'};
    
    DataPath(18) = {'./Data/UCI/Car.mat'};
    DataPath(19) = {'./Data/UCI/Mfeat.mat'};
    DataPath(20) = {'./Data/UCI/Dna.mat'};
    DataPath(21) = {'./Data/UCI/Segment.mat'};
    DataPath(22) = {'./Data/UCI/Satimage.mat'};
    DataPath(23) = {'./Data/UCI/Waveform.mat'};
    DataPath(24) = {'./Data/UCI/Letter.mat'};
    DataPath(25) = {'./Data/UCI/Protein.mat'};
    DataPath(26) = {'./Data/UCI/Poker.mat'};
    DataPath(27) = {'./Data/UCI/Shuttle.mat'};
    
   MaxStepl = 8;
    MaxStep2 = 8;
    %��������
   FunPara.ForLoopi = -MaxStepl:2:MaxStep2;
    FunPara.ForLoopj = -MaxStepl:2:MaxStep2;
    FunPara.ForLoopDelta = [2,6,10,20,25];
    FunPara.ForLoopPara = -6:6;
   FunPara.eps = 0.0001;
    for i = 1
        fprintf(fid,'i=%d Runing DataPath:%s\n',i, DataPath{i});
        fprintf('Runing DataPath:%s\n',DataPath{i});
        load([DataPath{i}]);
        Data.Type = 2;
        Data.X = mapminmax(X')';
        Data.Y = Y;
        clear X Y;
        Data = DataTypeTrans(Data,2);
        [ACallpara,FunPara] = MSSVMPara(Data,SVMFun,FunPara,fid);
        for idelta = 1:length(FunPara.ForLoopDelta)
            [M1,Ind1] = max(ACallpara(:,:,idelta));
            [ACbesetTemp(idelta), Ind2] = max(M1);
            optc1temp(idelta) = Ind1(Ind2);
            optc2temp(idelta) = Ind2;
        end
        ACall{i,1} = ACallpara;
        [ACallbest(i,:),Ind3] = max(ACbesetTemp);
        Paraall(i,:) = [FunPara.ForLoopi(optc1temp(Ind3)),FunPara.ForLoopj(optc2temp(Ind3)),FunPara.ForLoopDelta(Ind3)];%���ֵ����Ӧ�Ĳ���λ��
        name = ['ly_end_',num2str(i),'.mat']
        save(name,'ACall','ACallbest','Paraall')
    end
    fclose(fid);
end
load train;
sound(y,Fs);