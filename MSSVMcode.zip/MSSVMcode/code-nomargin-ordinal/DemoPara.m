clear
clc

SVMFunName = 'MSSVM';
SVMFun = str2func(SVMFunName);%�ַ���ת���ɺ�����
FunPara.kerfPara.type = 'lin';  %�˲���linΪ���Ժ�,rbfΪ��˹��
DirPath = sprintf('./Result/%s/Linearly/',SVMFunName);
if ~exist(DirPath,'dir')
    mkdir(DirPath);
end
for RunTimes = 1:10 
    FilePath = sprintf('%s%s%d.txt',DirPath,SVMFunName,RunTimes);
    fid = fopen(FilePath, 'wt');
    fprintf(fid, '%s Experment Time is %s \n', SVMFunName,date);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    DataNum =40;
    DataPath(1) = {'./Data/Pasture.mat'};
    DataPath(2) = {'./Data/Tae.mat'};
    DataPath(3) = {'./Data/Contact-lenses.mat'};
    DataPath(4) = {'./Data/Melanoma.mat'};
    DataPath(5) = {'./Data/Newthyroid.mat'};
    DataPath(6) = {'./Data/Winequality-red.mat'};
    DataPath(7) = {'./Data/Squash-stored.mat'};
    DataPath(8) = {'./Data/Squash-unstored.mat'};
    
    MaxStepl = 8;
    MaxStep2 = 8;
    %��������
    FunPara.ForLoopi = -MaxStepl:1:MaxStep2;
    FunPara.ForLoopj = -MaxStepl:1:MaxStep2;
    FunPara.ForLoopDelta = [2,4,6,8,10];
    FunPara.ForLoopPara = -6:6;
    FunPara.eps = 0.0001;
    
    for i = 1
        fprintf(fid,'i=%d Runing DataPath:%s\n',i, DataPath{i});
        fprintf('Runing DataPath:%s\n',DataPath{i});
        load([DataPath{i}]);
        Data.Type = 2;
        Data.X = mapminmax(X')';
        Data.Y = Y;
        clear X Y;
        Data = DataTypeTrans(Data,2);
        [ACallpara,FunPara] = MSSVMPara(Data,SVMFun,FunPara,fid);
        
        for idelta = 1:length(FunPara.ForLoopDelta)
            [M1,Ind1] = max(ACallpara(:,:,idelta));
            [ACbesetTemp(idelta), Ind2] = max(M1);
            optc1temp(idelta) = Ind1(Ind2);
            optc2temp(idelta) = Ind2;
        end
        ACall{i,1} = ACallpara;
        [ACallbest(i,:),Ind3] = max(ACbesetTemp);
        Paraall(i,:) = [FunPara.ForLoopi(optc1temp(Ind3)),FunPara.ForLoopj(optc2temp(Ind3)),FunPara.ForLoopDelta(Ind3)];%���ֵ����Ӧ�Ĳ���λ��
        name = ['ly_end_',num2str(i),'.mat']
        save(name,'ACall','ACallbest','Paraall')
    end
    fclose(fid);
end
load train;
sound(y,Fs);