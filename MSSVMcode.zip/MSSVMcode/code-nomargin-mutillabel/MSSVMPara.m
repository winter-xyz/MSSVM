function [ACallpara,FunPara] = MSSVMPara(Data,SVMFun,FunPara,fid)
%The Temple of ParaSearch
%fid is the handle of file for record
% ģ�庯���� FunPara.delta ��ΪѰ�ŵĲ������ø�ģ�彫SVMFun����Ѱ���滻����Ӧλ��
% �����2����������ʹ��2��ѭ����3������3��ѭ��
IsFile = 0;
if nargin==4,IsFile = 1;end
k = 10; %k�۽�����֤����
%������ʼ��
Best_AC = 0;
Proc = 0;Step = 0;
if strcmp(FunPara.kerfPara.type,'lin'),ForLoopPara = 0; else ForLoopPara = -6:6;end
iti = 0;
for i = FunPara.ForLoopi
    iti = iti + 1;
    itj = 0;
    for j = FunPara.ForLoopj
        itj = itj + 1;
        its = 0;
        for s = FunPara.ForLoopDelta
            its = its + 1;
            for Para = ForLoopPara
                FunPara.c1 = 10.^i;
                FunPara.c2 = 10.^j;
                FunPara.Delta = s;
                FunPara.kerfPara.pars = 2^Para;
                Perform = k_foldCV(Data,k,SVMFun,FunPara);
                ACallpara(iti,itj,its) = Perform.AP;
                if Perform.AP > Best_AC
                    Best_AC = Perform.AP
                    c1 = FunPara.c1;
                    c2 = FunPara.c2;
                    Delta = FunPara.Delta;
                    q=2^Para;
                    if Best_AC > 0.99,break;end
                end
                if Best_AC > 99,break;end
            end
            if Best_AC > 99,break;end
        end
    end
    if Best_AC > 99,break;end
    fprintf('Process %f,C1:%f,C2:%f,Delta:%f\n',Proc,c1,c2,Delta);
    fprintf('Process C1:%f,C2:%f,Delta:%f\n',c1,c2,Delta);
end
fprintf('Parameter Seaching is over!\n 10 fold Experment Processing Starting...\n');
fprintf('C1:%f,C2:%f,Delta:%f\n',c1,c2,Delta);