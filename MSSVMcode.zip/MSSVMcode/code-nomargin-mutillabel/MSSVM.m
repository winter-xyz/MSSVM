function [PredictY, Predict_pro] = MSSVM(TestX,DataTrain,FunPara)
[o.nSize,o.nfea] = size(DataTrain.X);
[~,c]=size(DataTrain.Y);
Ylabel = (1:c)';
nlabel = c;
PhiXY = cell(nlabel,1);
nCls = zeros(nlabel,1);
% for multi-mutillabel problem
[CMargin, id] = R_d(DataTrain.hf);
CMargin = CMargin + 1;
for i = 1:nlabel
    index = (DataTrain.Y(: , i) == 1);
    nCls(i) = sum(index);
    PhiXY{i} = DataTrain.X(index, :);
end
o.name = 'MSSVM';
o.CMargin = CMargin;
o.PhiXY = PhiXY;
o.nlabel = nlabel;
o.nCls = nCls;
o = train(o,FunPara);
d = zeros(size(TestX,1), o.nlabel);
for k = 1:o.nlabel
    if o.nCls(k)==0
        d(:,k)  = zeros(size(TestX,1),1)-999;
        continue
    end
    d(:,k) = TestX*o.W(:,k);
end
threshold = 0.5;
Predict_pro =1./(1+exp(-d));
PredictY =  Predict_pro > threshold;
end
function o = train(o,FunPara)
% �����
c1 = FunPara.c1; c2 = FunPara.c2; eps = FunPara.eps;
Phi_y = [];
Ind_Y = zeros(o.nlabel,2);
index = 1;
for i = 1:o.nlabel
    Ind_Y(i,:) = [index, index + o.nCls(i) - 1]; % bar(m_y)
    Phi_y  = [Phi_y; o.PhiXY{i}];
    index = index + o.nCls(i);
end
K =  Phi_y*Phi_y';
W = zeros(o.nfea,o.nlabel);
for i = 1:o.nlabel
    if o.nCls(i)==0
        W(:,i) = ones(o.nfea,1)-1;
        continue
    end
    ind_y = Ind_Y(i,1):Ind_Y(i,2);
    ind_ny = [1:Ind_Y(i,1)-1, Ind_Y(i,2)+1:size(Phi_y,1)]; % �޸ĺ�
    K_y = K(ind_y, ind_y);
    Pi_y = K(ind_y, ind_ny);
    G_y = [K_y -K_y; -K_y K_y];
    P_y = [Pi_y;-Pi_y];
    e_y = ones(o.nCls(i),1);
    YY_mar = o.CMargin(i,i);
    temp_ny = [];
    for j=1:o.nlabel
        if i~=j
            temp_ny = [temp_ny; o.CMargin(i,j)*ones(o.nCls(j),1)];
        end
    end
    tau_y = c2/(c1*sum(temp_ny));
    theta_y = min(tau_y,1);
    Lam_y = [-YY_mar*e_y;YY_mar*e_y];
    Lam_ny = temp_ny;
    H_y = -c1*P_y*Lam_ny + Lam_y + eps;
    LB = zeros(2*o.nCls(i),1);
    UB = [(c2/theta_y)*ones(o.nCls(i),1); c2*ones(o.nCls(i),1)];
    opts = optimset('Display','none');
    alpha = quadprog(G_y,H_y,[],[],[],[],LB,UB,[],opts);
    w1 = -c1*sum(Lam_ny.*Phi_y(ind_ny,:),1);
    w2 = sum( (alpha(1:o.nCls(i))- alpha(o.nCls(i)+1:end)).*Phi_y(ind_y,:), 1);
    W(:,i) = (w1 + w2)';
end
o.W = W;
end