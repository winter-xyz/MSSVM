function [d, ID] = R_d(enron)
R_start = enron(:,1);
R_end = enron(:,2);
father = setdiff(R_start,R_end);
son = setdiff(R_end,R_start);
middle = setdiff([R_start;R_end],[father;son]);
zuo = [son;middle;father];
for r_i = 1:length(zuo)
    t = 1;
    a = zuo(r_i,1);
    Table_ID(r_i,t) = a;
    while a ~= father
        t = t+1;
        num = find(R_end == a);
        Table_ID(r_i,t) = R_start(num,1);
        a = R_start(num,1);
    end
end
for i = 1:length(Table_ID)
    [~,L(i,1)] = find(Table_ID(i,:) == father);
end

ID = unique([R_start;R_end]);
d = zeros(length(ID),length(ID));
for i = 1:length(ID)
    for j = 1:length(ID)
        str = ID(i,1);
        en = ID(j,1);
        if i == j
            d(i,j) = 0;
        else
            a = find(Table_ID(:,1)==str);
            b = find(Table_ID(:,1)==en);
            r_a = Table_ID(a,1:L(a,1));
            r_b = Table_ID(b,1:L(b,1));
            d(i,j) = length(unique([r_a r_b]))-1;
        end
    end
end

    
    
