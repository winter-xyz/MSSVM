function [alpha] = dual_coordinate_descent(G_y, H_y, LB, UB, opts)
% 初始化 alpha
n = size(H_y, 1);
alpha = zeros(n,1);  %调整
max_iter = 500;
epsilon = 1e-8;
for iter = 1:max_iter
    alpha_prev = alpha;
    for i = 1:n
        G =  H_y(i);
        if alpha(i) == LB(i)
            PG = min(G, LB(i));
        elseif alpha(i) == UB(i)
            PG = max(G, LB(i));
        else
            PG = G;
        end
        if abs(PG) > epsilon
            alpha(i) = min(max(alpha(i) - PG / G_y(i, i), LB(i)), UB(i));
        end
    end
    if norm(alpha - alpha_prev) < epsilon
        break;
    end
end

