clear
clc

SVMFunName = 'MSSVM';
SVMFun = str2func(SVMFunName);
FunPara.kerfPara.type = 'lin'; %�˲���linΪ���Ժ�,rbfΪ��˹��
%�ǳ���Ҫ�������úã�ʵ������¼���ļ�·�����ļ������ļ����Զ�������
DirPath = sprintf('./Result/%s/Linear/',SVMFunName);
if ~exist(DirPath,'dir')
    mkdir(DirPath);
end
for RunTimes = 1:10 %�����ܹ��ܵĴ������ֱ��¼3���ļ�
    FilePath = sprintf('%s%s%d.txt',DirPath,SVMFunName,RunTimes);
    fid = fopen(FilePath, 'wt');
    fprintf(fid, '%s Experment Time is %s \n', SVMFunName,date);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    DataNum = 7;
    
    DataPath(1) = {'./Data/enron_0.mat'};
    DataPath(2) = {'./Data/enron_12.mat'};
    DataPath(3) = {'./Data/enron_1B.mat'};
    DataPath(4) = {'./Data/reuters_0.mat'};
    DataPath(5) = {'./Data/reuters_2.mat'};
    DataPath(6) = {'./Data/reuters_5.mat'};
    DataPath(7) = {'./Data/reuters_7.mat'};
    
    MaxStepl =8;
    MaxStep2 =8;
    FunPara.ForLoopi = -MaxStepl:2:MaxStep2;
    FunPara.ForLoopj = -MaxStepl:2:MaxStep2;
    FunPara.ForLoopDelta = [2,4,6,8,10];
    FunPara.ForLoopPara = -6:6;
    FunPara.eps = 0.0001;
    for i = 1
        fprintf(fid,'i=%d Runing DataPath:%s\n',i, DataPath{i});
        fprintf('Runing DataPath:%s\n',DataPath{i});
        load([DataPath{i}]);
        Data.Type = 2;
        Data.X = X;
        Data.Y = Y;
        Data.hf = enron; %ѡ�����ݼ�enron��reuters
        clear X Y enron;
        Data = DataTypeTrans(Data,2);
        [ACallpara,FunPara] = MSSVMPara(Data,SVMFun,FunPara,fid);
        for idelta = 1:length(FunPara.ForLoopDelta)
            [M1,Ind1] = max(ACallpara(:,:,idelta));
            [ACbesetTemp(idelta), Ind2] = max(M1);
            optc1temp(idelta) = Ind1(Ind2);
            optc2temp(idelta) = Ind2;
        end
        ACall{i,1} = ACallpara;
        [ACallbest(i,:),Ind3] = max(ACbesetTemp);
        Paraall(i,:) = [FunPara.ForLoopi(optc1temp(Ind3)),FunPara.ForLoopi(optc2temp(Ind3)),FunPara.ForLoopDelta(Ind3)];
        name = ['ly_end_',num2str(i),'.mat']
        save(name,'ACall','ACallbest','Paraall')
    end
    fclose(fid);
end
load train; 
sound(y,Fs);